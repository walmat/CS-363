UPDATE students SET name = ‘Scott’
WHERE ssn = 746897816;

UPDATE students SET snum = 1005
WHERE ssn = 746897816;

DELETE FROM register
WHERE when = ‘Spring2015’;