DROP TABLE students;
DROP TABLE departments;
DROP TABLE degrees;
DROP TABLE major;
DROP TABLE minor;
DROP TABLE courses;
DROP TABLE register;